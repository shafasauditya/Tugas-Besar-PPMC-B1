import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# x = jumlah kota
# y = jumlah 
# Worst time
x1 = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
y1 = np.array([3.261, 3.83, 4.319, 4.954, 5.502,6.074,6.673,7.187,7.841,8.534,8.9])

# Best time
x2 = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
y2 = np.array([3.162, 3.735, 4.246, 4.8, 5.323,5.951,6.55,7.002,7.627,8.226,8.798])

# Average time
x3 = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
y3 = np.array([3.1936, 3.7746, 4.2754, 4.8776, 5.377,5.9906,6.596,7.124,7.631,8.3332,8.8382])

std_dev_f3_f1 = np.std(y3 - y1)
std_dev_f3_f2 = np.std(y3 - y2)

# Plot the standard deviation
plt.plot(x1,np.abs(y3 - y1), label='Std Dev (Big Theta - Big O)')
plt.plot(x1,np.abs(y3 - y2), label='Std Dev (Big Theta - Big Omega)')

# Plot the functions
plt.scatter(x1, y1, color='red', label='Worst time')
plt.scatter(x2, y2, color='blue', label='Best time')
plt.scatter(x3, y3, color='green', label='average time')

# Perform linear regression
slope1, intercept1, _, _, _ = stats.linregress(x1, y1)
slope2, intercept2, _, _, _ = stats.linregress(x2, y2)
slope3, intercept3, _, _, _ = stats.linregress(x3, y3)

# Plot the regression lines
plt.plot(x1, slope1*x1 + intercept1, color='red', linestyle='--', label='Big O')
plt.plot(x2, slope2*x2 + intercept2, color='blue', linestyle='--', label='Big Omega')
plt.plot(x3, slope3*x3 + intercept3, color='green', linestyle='--', label='Big Theta')

# Add legend and labels
plt.legend()
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Functions and Linear Regression')
plt.grid(True)

# Show plot
plt.show()


