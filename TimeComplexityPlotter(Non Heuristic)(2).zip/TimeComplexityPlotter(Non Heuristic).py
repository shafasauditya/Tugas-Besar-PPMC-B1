import numpy as np
import matplotlib.pyplot as plt
from scipy.special import gamma

# Data points
# Average case(Big theta)
x1 = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
y1 = np.array([gamma(7), gamma(8),gamma(9), gamma(10), gamma(11), gamma(12), gamma(13), gamma(14), gamma(15), gamma(16), gamma(17)])
# Worst Case(Big O)
x2 = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
y2 = np.array([gamma(7), gamma(8),gamma(9), gamma(10), gamma(11), gamma(12), gamma(13), gamma(14), gamma(15), gamma(16), gamma(17)])
# Best Case(Big Omega)
x3 = np.array([6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
y3 = np.array([gamma(7), gamma(8),gamma(9), gamma(10), gamma(11), gamma(12), gamma(13), gamma(14), gamma(15), gamma(16), gamma(17)])

plt.yscale('log')

# Plot the functions
plt.scatter(x1, np.log(y1), color='red', label='Average time')
plt.scatter(x2, np.log(y2), color='blue', label='Worst time')
plt.scatter(x3, np.log(y3), color='green', label='Best time')

# Theoretical Big O (O(N!))
theoretical_Big_O = np.log(gamma((x1+1)*y3[0]/gamma(7)))
plt.plot(x1, theoretical_Big_O, label='Theoretical Big O (O(N!))', color='orange')

# Add legend and labels
plt.legend()
plt.xlabel('X')
plt.ylabel('Log(Y)')
plt.title('Functions and Theoretical Big O')
plt.grid(True)

# Show plot
plt.show()
